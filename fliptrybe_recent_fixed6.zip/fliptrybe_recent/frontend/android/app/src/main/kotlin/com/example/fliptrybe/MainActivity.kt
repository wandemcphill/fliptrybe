package com.example.fliptrybe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
