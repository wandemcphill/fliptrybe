import 'package:flutter/material.dart';

class ShortletsScreen extends StatelessWidget {
  const ShortletsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Shortlets')),
      body: const Center(child: Text('Coming soon')),
    );
  }
}
