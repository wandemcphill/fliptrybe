import 'package:flutter/material.dart';

import '../services/order_service.dart';
import '../services/driver_directory_service.dart';
import 'receipts_by_order_screen.dart';
import 'receipts_screen.dart';

class OrderDetailScreen extends StatefulWidget {
  final int orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  final _svc = OrderService();
  final _driversSvc = DriverDirectoryService();

  List<dynamic> _drivers = const [];
  int? _selectedDriverId;
  final _driverFilterState = TextEditingController();
  final _driverFilterCity = TextEditingController();
  final _driverFilterLocality = TextEditingController();

  final _filterState = TextEditingController();
  final _filterCity = TextEditingController();
  final _filterLocality = TextEditingController();

  bool _loading = true;
  String? _error;

  Map<String, dynamic>? _order;
  List<dynamic> _events = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final detail = await _svc.getOrder(widget.orderId);
      final tl = await _svc.timeline(widget.orderId);
      final drivers = await _driversSvc.listDrivers(
        state: _driverFilterState.text,
        city: _driverFilterCity.text,
        locality: _driverFilterLocality.text,
      );

      setState(() {
        _order = detail;
        _events = tl;
        _drivers = drivers;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _merchantAccept() async {
    final ok = await _svc.merchantAccept(widget.orderId);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? "Merchant accepted ✅" : "Not allowed / failed")));
    if (ok) _load();
  }

  Future<void> _assignDriver() async {
    final did = _selectedDriverId;
    if (did == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select a driver first')));
      return;
    }
    final ok = await _svc.assignDriver(widget.orderId, did);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? 'Driver assigned ✅' : 'Not allowed / failed')));
    if (ok) _load();
  }

  Future<void> _driverPickedUp() async {
    final ok = await _svc.driverSetStatus(widget.orderId, "picked_up");
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? "Marked picked up ✅" : "Not allowed / failed")));
    if (ok) _load();
  }

  Future<void> _driverDelivered() async {
    final ok = await _svc.driverSetStatus(widget.orderId, "delivered");
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ok ? "Delivered ✅ (Receipts auto-generated)" : "Not allowed / failed")));
    if (ok) _load();
  }

  Widget _pill(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.grey.shade200,
      ),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
    );
  }

  Widget _eventTile(Map<String, dynamic> m) {
    final at = (m['created_at'] ?? '').toString();
    final label = (m['event'] ?? '').toString();
    final note = (m['note'] ?? '').toString();
    return ListTile(
      dense: true,
      leading: const Icon(Icons.check_circle_outline),
      title: Text(label),
      subtitle: Text(note.isEmpty ? at : "$note\n$at"),
    );
  }

  @override
  Widget build(BuildContext context) {
    final status = (_order?['status'] ?? '').toString();

    return Scaffold(
      appBar: AppBar(
        title: Text("Order #${widget.orderId}"),
        actions: [IconButton(onPressed: _loading ? null : _load, icon: const Icon(Icons.refresh))],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : (_error != null)
              ? Center(child: Text(_error!))
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    _pill("Status: $status"),
                    const SizedBox(height: 12),

                    OutlinedButton.icon(
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ReceiptsScreen()));
                      },
                      icon: const Icon(Icons.receipt_long),
                      label: const Text("View Receipts"),
                    ),

                    const SizedBox(height: 12),
                    Text(
                      "Amount: ₦${_order?['amount'] ?? 0}",
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    Text("Delivery Fee: ₦${_order?['delivery_fee'] ?? 0}", style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    if ((_order?['pickup'] ?? '').toString().isNotEmpty) Text("Pickup: ${_order?['pickup']}"),
                    if ((_order?['dropoff'] ?? '').toString().isNotEmpty) Text("Dropoff: ${_order?['dropoff']}"),
                    const SizedBox(height: 14),

                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        ElevatedButton.icon(
                          onPressed: _merchantAccept,
                          icon: const Icon(Icons.storefront),
                          label: const Text("Merchant Accept"),
                        ),
                        ElevatedButton.icon(
                          onPressed: _driverPickedUp,
                          icon: const Icon(Icons.local_shipping_outlined),
                          label: const Text("Driver Picked Up"),
                        ),
                        ElevatedButton.icon(
                          onPressed: _driverDelivered,
                          icon: const Icon(Icons.check_circle_outline),
                          label: const Text("Driver Delivered"),
                        ),
                      ],
                    ),

                    const Divider(height: 28),
                    const Text("Timeline", style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    if (_events.isEmpty)
                      const Text("No events yet.")
                    else
                      ..._events.whereType<Map>().map((e) => _eventTile(Map<String, dynamic>.from(e))),
                  ],
                ),
    );
  }
}
