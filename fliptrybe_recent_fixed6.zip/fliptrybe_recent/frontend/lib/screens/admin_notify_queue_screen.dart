import 'package:flutter/material.dart';

class AdminNotifyQueueScreen extends StatelessWidget {
  const AdminNotifyQueueScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notify Queue')),
      body: const Center(child: Text('Coming soon')),
    );
  }
}
