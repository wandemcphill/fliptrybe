import 'dart:io' show Platform;

import 'package:flutter/foundation.dart' show kIsWeb;

class ApiConfig {
  /// Override at build/run time:
  /// flutter run --dart-define=BASE_URL=http://127.0.0.1:5000
  static const String _baseUrlEnv = String.fromEnvironment('BASE_URL', defaultValue: '');

  /// Android-specific override (for device/LAN testing):
  /// flutter run --dart-define=ANDROID_BASE_URL=http://192.168.1.50:5000
  static const String _androidBaseUrlEnv = String.fromEnvironment('ANDROID_BASE_URL', defaultValue: '');

  static String get baseUrl {
    if (_baseUrlEnv.isNotEmpty) {
      return _baseUrlEnv;
    }
    if (kIsWeb) {
      return 'http://127.0.0.1:5000';
    }
    if (Platform.isAndroid) {
      return _androidBaseUrlEnv.isNotEmpty ? _androidBaseUrlEnv : 'http://10.0.2.2:5000';
    }
    return 'http://127.0.0.1:5000';
  }

  /// Builds a full API URL under /api
  /// Example: ApiConfig.api('/auth/me') -> http://127.0.0.1:5000/api/auth/me
  static String api(String path) {
    var p = path.trim();
    if (!p.startsWith('/')) p = '/$p';

    // If caller already included /api, don't double it
    if (p.startsWith('/api/')) return '$baseUrl$p';

    return '$baseUrl/api$p';
  }
}
