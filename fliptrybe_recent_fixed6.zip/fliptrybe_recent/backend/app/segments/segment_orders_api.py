from __future__ import annotations

import os
import random
from datetime import datetime

from flask import Blueprint, jsonify, request

from app.extensions import db
from app.models import User, Listing, Order, OrderEvent, Receipt, Notification, UserSettings
from app.utils.jwt_utils import decode_token
from app.utils.receipts import create_receipt
from app.utils.commission import compute_commission, resolve_rate, RATES
from app.utils.messaging import enqueue_sms, enqueue_whatsapp
from app.jobs.escrow_runner import _hold_order_into_escrow, _release_escrow

orders_bp = Blueprint("orders_bp", __name__, url_prefix="/api")


_INIT_DONE = False


@orders_bp.before_app_request
def _ensure_tables_once():
    global _INIT_DONE
    if _INIT_DONE:
        return
    try:
        db.create_all()
    except Exception:
        pass
    _INIT_DONE = True


def _bearer_token() -> str | None:
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return None
    return header.replace("Bearer ", "", 1).strip() or None


def _current_user() -> User | None:
    token = _bearer_token()
    if not token:
        return None
    payload = decode_token(token)
    if not payload:
        return None
    sub = payload.get("sub")
    if not sub:
        return None
    try:
        uid = int(sub)
    except Exception:
        return None
    return User.query.get(uid)


def _role(u: User | None) -> str:
    if not u:
        return "guest"
    return (getattr(u, "role", None) or "buyer").strip().lower()


def _is_admin(u: User | None) -> bool:
    if not u:
        return False
    try:
        if int(u.id or 0) == 1:
            return True
    except Exception:
        pass
    return _role(u) == "admin"


def _event(order_id: int, actor_id: int | None, event: str, note: str = "") -> None:
    try:
        key = f"order:{int(order_id)}:{event}:{int(actor_id) if actor_id is not None else 'system'}"
        existing = OrderEvent.query.filter_by(idempotency_key=key[:160]).first()
        if existing:
            return
        e = OrderEvent(
            order_id=order_id,
            actor_user_id=actor_id,
            event=event,
            note=note[:240],
            idempotency_key=key[:160],
        )
        db.session.add(e)
        db.session.commit()
    except Exception:
        db.session.rollback()


def _receipt_once(*, user_id: int, kind: str, reference: str, amount: float, description: str, meta: dict):
    """Create a receipt only if one doesn't already exist for (user_id, kind, reference)."""
    try:
        existing = Receipt.query.filter_by(user_id=user_id, kind=kind, reference=reference).first()
        if existing:
            return existing
        rate = float(resolve_rate(kind, state=str(meta.get('state','')) if meta else '', category=str(meta.get('category','')) if meta else ''))
        try:
            if kind == "listing_sale" and (meta or {}).get("role") == "merchant":
                rate = 0.0
        except Exception:
            pass
        fee = compute_commission(amount, rate)
        total = float(amount) + float(fee)
        rec = create_receipt(
            user_id=user_id,
            kind=kind,
            reference=reference,
            amount=amount,
            fee=fee,
            total=total,
            description=description,
            meta={**(meta or {}), "rate": rate},
        )
        db.session.commit()
        return rec
    except Exception:
        db.session.rollback()
        return None


def _notify_user(user_id: int, title: str, body: str, channel: str = "in_app"):
    """Queue a notification respecting user settings (demo sender later flushes)."""
    try:
        settings = UserSettings.query.filter_by(user_id=user_id).first()
        if settings:
            if channel == "sms" and not bool(settings.notif_sms):
                return
            if channel == "whatsapp" and not bool(settings.notif_whatsapp):
                return
            if channel == "in_app" and not bool(settings.notif_in_app):
                return
        n = Notification(user_id=user_id, channel=channel, title=title[:140], body=body, status="queued")
        db.session.add(n)
        db.session.commit()
    except Exception:
        db.session.rollback()


def _parse_bool(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return int(value) == 1
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "y")
    return False

def _gen_delivery_code() -> str:
    # 4-digit code, avoid leading zeros confusion by allowing them but formatting fixed length
    try:
        return f"{random.randint(0, 9999):04d}"
    except Exception:
        return "0000"


def _mark_paid(order: Order, reference: str | None = None, actor_id: int | None = None) -> None:
    if reference:
        order.payment_reference = reference
    order.status = "paid"
    if order.inspection_required:
        order.release_condition = "INSPECTION_PASS"
    else:
        order.release_condition = "BUYER_CONFIRM"
    _hold_order_into_escrow(order)
    if not order.inspection_required:
        _release_escrow(order)
    # Notify buyer & merchant via SMS/WhatsApp (trust layer) when payment is confirmed
    try:
        buyer = User.query.get(int(order.buyer_id))
        merchant = User.query.get(int(order.merchant_id))
        msg_buyer = f"FlipTrybe: Payment confirmed for Order #{int(order.id)}. Keep your delivery code safe." 
        msg_merchant = f"FlipTrybe: Sale confirmed for Order #{int(order.id)}. Prepare item for dispatch." 
        if buyer and getattr(buyer, 'phone', None):
            enqueue_sms(buyer.phone, msg_buyer, reference=f"order:{int(order.id)}:paid:sms:buyer")
            enqueue_whatsapp(buyer.phone, msg_buyer, reference=f"order:{int(order.id)}:paid:wa:buyer")
        if merchant and getattr(merchant, 'phone', None):
            enqueue_sms(merchant.phone, msg_merchant, reference=f"order:{int(order.id)}:paid:sms:merchant")
            enqueue_whatsapp(merchant.phone, msg_merchant, reference=f"order:{int(order.id)}:paid:wa:merchant")
    except Exception:
        pass
    if actor_id is not None:
        try:
            _event(int(order.id), int(actor_id), "paid", "Order marked paid")
        except Exception:
            pass


@orders_bp.post("/orders")
def create_order():
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    payload = request.get_json(silent=True) or {}

    try:
        buyer_id = int(payload.get("buyer_id") or u.id)
    except Exception:
        buyer_id = int(u.id)

    if buyer_id != int(u.id) and not _is_admin(u):
        return jsonify({"message": "Forbidden"}), 403

    try:
        merchant_id = int(payload.get("merchant_id"))
    except Exception:
        return jsonify({"message": "merchant_id required"}), 400

    listing_id = payload.get("listing_id")
    try:
        listing_id_int = int(listing_id) if listing_id is not None else None
    except Exception:
        listing_id_int = None

    try:
        amount = float(payload.get("amount") or 0.0)
    except Exception:
        amount = 0.0

    try:
        delivery_fee = float(payload.get("delivery_fee") or 0.0)
    except Exception:
        delivery_fee = 0.0
    try:
        inspection_fee = float(payload.get("inspection_fee") or 0.0)
    except Exception:
        inspection_fee = 0.0

    pickup = (payload.get("pickup") or "").strip()
    dropoff = (payload.get("dropoff") or "").strip()
    payment_reference = (payload.get("payment_reference") or "").strip()
    inspection_required = _parse_bool(payload.get("inspection_required"))

    # If listing_id is supplied, align merchant if listing exists and has owner.
    listing = None
    if listing_id_int:
        listing = Listing.query.get(listing_id_int)
        if listing and getattr(listing, "owner_id", None):
            try:
                merchant_id = int(getattr(listing, "owner_id"))
            except Exception:
                pass

        # Seller cannot buy their own listing
    try:
        if int(buyer_id) == int(merchant_id) and not _is_admin(u):
            return jsonify({"message": "Sellers cannot buy their own listings"}), 409
    except Exception:
        pass

# If listing provided, prefer listing pricing rules over payload amount
    if listing:
        try:
            seller = User.query.get(int(merchant_id))
            seller_role = (getattr(seller, "role", "") or "buyer").strip().lower()
            if seller_role in ("driver", "inspector"):
                seller_role = "merchant"
        except Exception:
            seller_role = "buyer"

        base_price = float(getattr(listing, "base_price", 0.0) or 0.0)
        if base_price <= 0.0:
            base_price = float(getattr(listing, "price", 0.0) or 0.0)
        platform_fee = float(getattr(listing, "platform_fee", 0.0) or 0.0)
        final_price = float(getattr(listing, "final_price", 0.0) or 0.0)

        if seller_role == "merchant":
            if platform_fee <= 0.0:
                platform_fee = round(base_price * 0.03, 2)
            if final_price <= 0.0:
                final_price = round(base_price + platform_fee, 2)
            amount = float(final_price)
        else:
            amount = float(base_price)

    order = Order(
        buyer_id=buyer_id,
        merchant_id=merchant_id,
        listing_id=listing_id_int,
        amount=amount,
        delivery_fee=delivery_fee,
        inspection_fee=inspection_fee,
        pickup=pickup,
        dropoff=dropoff,
        payment_reference=payment_reference,
        inspection_required=inspection_required,
        status="created",
        updated_at=datetime.utcnow(),
    )

    try:
        db.session.add(order)
        db.session.commit()
        if payment_reference:
            _mark_paid(order, payment_reference, actor_id=int(u.id))
            order.updated_at = datetime.utcnow()
            db.session.add(order)
            db.session.commit()
        _event(order.id, u.id, "created", "Order created")
        _notify_user(int(order.merchant_id), "New Order", f"You received a new order #{int(order.id)}")
        _notify_user(int(order.buyer_id), "Order Created", f"Your order #{int(order.id)} was created")
        return jsonify({"ok": True, "order": order.to_dict()}), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed to create order", "error": str(e)}), 500


@orders_bp.post("/orders/<int:order_id>/mark-paid")
def mark_paid(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if not (_is_admin(u) or int(o.buyer_id) == int(u.id)):
        return jsonify({"message": "Forbidden"}), 403

    payload = request.get_json(silent=True) or {}
    reference = (payload.get("reference") or payload.get("payment_reference") or "").strip()

    try:
        _mark_paid(o, reference if reference else None, actor_id=int(u.id))
        o.updated_at = datetime.utcnow()
        db.session.add(o)
        db.session.commit()
        return jsonify({"ok": True, "order": o.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed", "error": str(e)}), 500


@orders_bp.get("/orders/my")
def my_orders():
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    rows = Order.query.filter_by(buyer_id=u.id).order_by(Order.created_at.desc()).limit(200).all()
    return jsonify([o.to_dict() for o in rows]), 200


@orders_bp.get("/merchant/orders")
def merchant_orders():
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    r = _role(u)
    if r not in ("merchant", "admin"):
        return jsonify([]), 200

    rows = Order.query.filter_by(merchant_id=u.id).order_by(Order.created_at.desc()).limit(200).all()
    return jsonify([o.to_dict() for o in rows]), 200


@orders_bp.get("/orders/<int:order_id>")
def get_order(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if not (_is_admin(u) or int(u.id) in (int(o.buyer_id), int(o.merchant_id)) or (o.driver_id and int(o.driver_id) == int(u.id))):
        return jsonify({"message": "Forbidden"}), 403

    return jsonify(o.to_dict()), 200


@orders_bp.get("/orders/<int:order_id>/timeline")
def timeline(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if not (_is_admin(u) or int(u.id) in (int(o.buyer_id), int(o.merchant_id)) or (o.driver_id and int(o.driver_id) == int(u.id))):
        return jsonify({"message": "Forbidden"}), 403

    events = OrderEvent.query.filter_by(order_id=order_id).order_by(OrderEvent.created_at.asc()).all()
    return jsonify({"ok": True, "items": [e.to_dict() for e in events]}), 200


@orders_bp.post("/orders/<int:order_id>/merchant/accept")
def merchant_accept(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if int(o.merchant_id) != int(u.id) and not _is_admin(u):
        return jsonify({"message": "Forbidden"}), 403

    o.status = "merchant_accepted"
    o.updated_at = datetime.utcnow()

    # Demo auto-assign driver for demo listings (keeps role checks intact)
    # Skip if already assigned (e.g., smoke test wants a fresh accept).
    try:
        if o.driver_id is None and o.listing_id:
            listing = Listing.query.get(int(o.listing_id))
            if listing:
                title = (listing.title or "")
                desc = (listing.description or "")
                if (title.startswith("Demo Listing #") or ("investor demo" in desc.lower())) and os.getenv("DEMO_AUTO_ASSIGN_DRIVER", "0") == "1":
                    demo_driver = User.query.filter_by(email="driver@fliptrybe.com").first()
                    if demo_driver:
                        o.driver_id = int(demo_driver.id)
                        o.status = "driver_assigned"
    except Exception:
        pass

    try:
        db.session.add(o)
        db.session.commit()
        _event(o.id, u.id, "merchant_accepted", "Merchant accepted order")
        _notify_user(int(o.buyer_id), "Order Accepted", f"Merchant accepted your order #{int(o.id)}")
        # SMS/WhatsApp delivery-code distribution (non-PII, trust-critical)
        try:
            buyer = User.query.get(int(o.buyer_id))
            merchant = User.query.get(int(o.merchant_id))
            driver = User.query.get(int(o.driver_id)) if o.driver_id else None
            if merchant and getattr(merchant, "phone", None):
                msg = f"FlipTrybe: Pickup code for Order #{int(o.id)} is {o.pickup_code}. Share ONLY with the assigned driver at pickup."
                enqueue_sms(merchant.phone, msg, reference=f"order:{int(o.id)}:pickup_code:sms:merchant")
                enqueue_whatsapp(merchant.phone, msg, reference=f"order:{int(o.id)}:pickup_code:wa:merchant")
            if buyer and getattr(buyer, "phone", None):
                msg = f"FlipTrybe: Delivery code for Order #{int(o.id)} is {o.dropoff_code}. Share ONLY with the driver when item is delivered."
                enqueue_sms(buyer.phone, msg, reference=f"order:{int(o.id)}:dropoff_code:sms:buyer")
                enqueue_whatsapp(buyer.phone, msg, reference=f"order:{int(o.id)}:dropoff_code:wa:buyer")
            if driver and getattr(driver, "phone", None):
                msg = f"FlipTrybe: Order #{int(o.id)} codes. Pickup: {o.pickup_code}. Dropoff: {o.dropoff_code}. Keep private."
                enqueue_sms(driver.phone, msg, reference=f"order:{int(o.id)}:codes:sms:driver")
                enqueue_whatsapp(driver.phone, msg, reference=f"order:{int(o.id)}:codes:wa:driver")
        except Exception:
            pass
        return jsonify({"ok": True, "order": o.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed", "error": str(e)}), 500


@orders_bp.post("/orders/<int:order_id>/driver/assign")
def assign_driver(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    # merchant or admin can assign. Drivers accept via /driver/jobs/<id>/accept
    if int(o.merchant_id) != int(u.id) and not _is_admin(u):
        return jsonify({"message": "Forbidden"}), 403

    payload = request.get_json(silent=True) or {}
    try:
        driver_id = int(payload.get("driver_id"))
    except Exception:
        return jsonify({"message": "driver_id required"}), 400

    o.driver_id = driver_id
    o.status = "driver_assigned"
    o.updated_at = datetime.utcnow()

    try:
        db.session.add(o)
        db.session.commit()
        _event(o.id, u.id, "driver_assigned", f"Assigned driver {driver_id}")
        _notify_user(int(driver_id), "New Delivery Job", f"You were assigned order #{int(o.id)}")
        return jsonify({"ok": True, "order": o.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed", "error": str(e)}), 500


@orders_bp.post("/orders/<int:order_id>/driver/status")
def driver_status(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if not (o.driver_id and int(o.driver_id) == int(u.id)) and not _is_admin(u):
        return jsonify({"message": "Forbidden"}), 403

    payload = request.get_json(silent=True) or {}
    status = (payload.get("status") or "").strip().lower()

    allowed = ("picked_up", "delivered", "completed")
    if status not in allowed:
        return jsonify({"message": "Invalid status"}), 400

    if status in ("delivered", "completed") and (o.escrow_status or "NONE") != "RELEASED":
        return jsonify({"message": "Escrow must be RELEASED before delivery completion"}), 409

    o.status = status
    o.updated_at = datetime.utcnow()

    try:
        db.session.add(o)
        db.session.commit()
        _event(o.id, u.id, status, f"Driver set status to {status}")

        # In-app notifications
        if status == "picked_up":
            _notify_user(int(o.buyer_id), "Picked Up", f"Driver picked up your order #{int(o.id)}")
            _notify_user(int(o.merchant_id), "Picked Up", f"Order #{int(o.id)} has been picked up")
        elif status in ("delivered", "completed"):
            _notify_user(int(o.buyer_id), "Delivered", f"Your order #{int(o.id)} was delivered")
            _notify_user(int(o.merchant_id), "Delivered", f"Order #{int(o.id)} was delivered")
            _notify_user(int(o.driver_id or u.id), "Completed", f"Delivery completed for order #{int(o.id)}")

        # Auto-receipts on delivered/completed (idempotent)
        if status in ("delivered", "completed"):
            ref = f"order:{int(o.id)}"
            seller_role = "buyer"
            try:
                seller = User.query.get(int(o.merchant_id))
                seller_role = (getattr(seller, "role", "") or "buyer").strip().lower()
                if seller_role in ("driver", "inspector"):
                    seller_role = "merchant"
            except Exception:
                seller_role = "buyer"
            _receipt_once(
                user_id=int(o.merchant_id),
                kind="listing_sale",
                reference=ref,
                amount=float(o.amount or 0.0),
                description="Listing sale commission",
                meta={"order_id": int(o.id), "role": seller_role},
            )

            # Buyer commission on delivery
            _receipt_once(
                user_id=int(o.buyer_id),
                kind="delivery",
                reference=ref,
                amount=float(o.delivery_fee or 0.0),
                description="Delivery commission",
                meta={"order_id": int(o.id), "role": "buyer"},
            )

        return jsonify({"ok": True, "order": o.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed", "error": str(e)}), 500


@orders_bp.get("/orders/<int:order_id>/codes")
def get_delivery_codes(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    # Only participants can view codes, and never reveal both to buyer/merchant.
    is_admin = _is_admin(u)
    is_buyer = int(o.buyer_id) == int(u.id)
    is_merchant = int(o.merchant_id) == int(u.id)
    is_driver = (o.driver_id is not None and int(o.driver_id) == int(u.id))

    if not (is_admin or is_buyer or is_merchant or is_driver):
        return jsonify({"message": "Forbidden"}), 403

    data = {"order_id": int(o.id)}
    if is_admin or is_driver:
        data["pickup_code"] = o.pickup_code or ""
        data["dropoff_code"] = o.dropoff_code or ""
    elif is_merchant:
        data["pickup_code"] = o.pickup_code or ""
    elif is_buyer:
        data["dropoff_code"] = o.dropoff_code or ""

    return jsonify({"ok": True, "codes": data}), 200


def _bump_attempts(o: Order, which: str) -> bool:
    """Returns True if still allowed, False if locked."""
    try:
        if which == "pickup":
            o.pickup_code_attempts = int(o.pickup_code_attempts or 0) + 1
            return int(o.pickup_code_attempts) < 4
        o.dropoff_code_attempts = int(o.dropoff_code_attempts or 0) + 1
        return int(o.dropoff_code_attempts) < 4
    except Exception:
        return False


@orders_bp.post("/orders/<int:order_id>/driver/confirm-pickup")
def driver_confirm_pickup(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if not (_is_admin(u) or (o.driver_id and int(o.driver_id) == int(u.id))):
        return jsonify({"message": "Forbidden"}), 403

    payload = request.get_json(silent=True) or {}
    code = (payload.get("code") or "").strip()

    if not o.pickup_code or not code:
        return jsonify({"message": "Pickup code not set"}), 409

    if code != str(o.pickup_code):
        allowed = _bump_attempts(o, "pickup")
        try:
            db.session.add(o)
            db.session.commit()
        except Exception:
            db.session.rollback()
        if not allowed:
            return jsonify({"message": "Pickup code locked. Contact admin."}), 423
        return jsonify({"message": "Invalid pickup code"}), 400

    o.pickup_confirmed_at = datetime.utcnow()
    if o.status in ("merchant_accepted", "driver_assigned"):
        o.status = "picked_up"
    o.updated_at = datetime.utcnow()
    try:
        db.session.add(o)
        db.session.commit()
        _event(o.id, u.id, "picked_up", "Pickup code confirmed")
        _notify_user(int(o.buyer_id), "Picked Up", f"Driver picked up your order #{int(o.id)}")
        _notify_user(int(o.merchant_id), "Picked Up", f"Order #{int(o.id)} has been picked up")
        return jsonify({"ok": True, "order": o.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed", "error": str(e)}), 500


@orders_bp.post("/orders/<int:order_id>/driver/confirm-dropoff")
def driver_confirm_dropoff(order_id: int):
    u = _current_user()
    if not u:
        return jsonify({"message": "Unauthorized"}), 401

    o = Order.query.get(order_id)
    if not o:
        return jsonify({"message": "Not found"}), 404

    if not (_is_admin(u) or (o.driver_id and int(o.driver_id) == int(u.id))):
        return jsonify({"message": "Forbidden"}), 403

    payload = request.get_json(silent=True) or {}
    code = (payload.get("code") or "").strip()

    if not o.dropoff_code or not code:
        return jsonify({"message": "Dropoff code not set"}), 409

    if code != str(o.dropoff_code):
        allowed = _bump_attempts(o, "dropoff")
        try:
            db.session.add(o)
            db.session.commit()
        except Exception:
            db.session.rollback()
        if not allowed:
            return jsonify({"message": "Dropoff code locked. Contact admin."}), 423
        return jsonify({"message": "Invalid dropoff code"}), 400

    if (o.escrow_status or "NONE") != "RELEASED":
        return jsonify({"message": "Escrow must be RELEASED before dropoff confirmation"}), 409

    o.dropoff_confirmed_at = datetime.utcnow()
    o.status = "delivered"
    o.updated_at = datetime.utcnow()

    try:
        db.session.add(o)
        db.session.commit()
        _event(o.id, u.id, "delivered", "Dropoff code confirmed")
        _notify_user(int(o.buyer_id), "Delivered", f"Your order #{int(o.id)} was delivered")
        _notify_user(int(o.merchant_id), "Delivered", f"Order #{int(o.id)} was delivered")
        return jsonify({"ok": True, "order": o.to_dict()}), 200
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": "Failed", "error": str(e)}), 500

