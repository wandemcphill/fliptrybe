"""Realtime helpers.

FlipTrybe can optionally use Socket.IO for live updates.
These modules provide a safe interface even when SocketIO is disabled.
"""
