"""Payments package.

This small package exists to satisfy imports from legacy segments.
The canonical implementation currently lives in `app.segments.segment_payments_engine`.
"""
