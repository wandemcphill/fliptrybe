def run_smoke_tests(): pass

def emergency_shutdown(): pass
