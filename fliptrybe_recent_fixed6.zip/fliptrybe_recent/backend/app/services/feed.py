def record_view(user_id, listing_id): pass

def recommend(user_id): return []
